from pathlib import Path
import hashlib,json,re,subprocess,tarfile
ROOT=Path('/Users/tofu/.hermes/cache/scratch/kh-save-r1')
OUT=Path(__file__).resolve().parent
summary={'base':'e191b99d1806682888557e415ab82c99f9185fb0','worktree':str(ROOT),'branch':'fix/save-r1-path-resolution','common_dir':subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=ROOT,text=True).strip(),'runs':{}}
for name in ['reviewer-red','reviewer-green','seams-red-corrected','final-path-red','final-path-green','final-path-sanitized','prior-final','prior-sanitized','prior-sanitized-final','original-extra']:
    file=OUT/name/('extra-test-results.json' if name=='original-extra' else 'test-results.json' if name.startswith('prior') else 'results.json')
    data=json.loads(file.read_text()); rows=data if isinstance(data,list) else data['results']
    parsed=[]; adversarial=[]; original=[]
    for r in rows:
        text=Path(r.get('log',r.get('output'))).read_text()
        matches=[tuple(map(int,x)) for x in re.findall(r'RESULT .*?: (\d+) checks, (\d+) failed',text)]
        parsed+=matches
        if 'adversarial-' in r['label'] or r['label'].startswith('sanitized-'): adversarial+=matches
        if r['label'].startswith('original-') and 'build' not in r['label']: original+=matches
    entry=dict(commands=len(rows),failed_commands=[r['label'] for r in rows if r['exit_code']],result_cases=len(parsed),result_checks=sum(x[0] for x in parsed),failed_result_checks=sum(x[1] for x in parsed))
    if adversarial: entry.update(adversarial_cases=len(adversarial),adversarial_checks=sum(x[0] for x in adversarial),failed_adversarial_checks=sum(x[1] for x in adversarial))
    if original: entry.update(original_cases=len(original),original_checks=sum(x[0] for x in original))
    summary['runs'][name]=entry
    if name in ['final-path-green','final-path-sanitized','prior-final','prior-sanitized-final','original-extra']: assert not entry['failed_commands'],entry
summary['hashes']={}
for f in ['dm/host/hle_fs.c','dm/host/dmhost','dm/host/gen/010090C022978003/game_profile.h','dm/host/gen/010090C022978001/game_profile.h','dm/games/010090C022978000/direct-profiles/010090C022978003/game.tsv','dm/host/tests/t_fs_path_resolution.c','dm/host/tests/t_fs_path_seams.c','dm/host/tests/run_save_review.py','dm/host/tests/run_save_path_resolution.py']:
    p=ROOT/f;summary['hashes'][f]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size)
log=(OUT/'mac-build.log').read_text()
summary['mac_build']=dict(exit_code=0,command='make -C dm/host -j4 GAME=010090C022978003 DM_GAMES_DIR="$PWD/dm/games/010090C022978000/direct-profiles" DM_GAMES_FIRST=1',warnings=len(re.findall('warning:',log)),hle_fs_warning=bool(re.search(r'hle_fs.c:.*warning',log)),game_stamp=(ROOT/'dm/host/gen/game.stamp').read_text().strip())
old=subprocess.check_output(['git','show',summary['base']+':dm/host/hle_fs.c'],cwd=ROOT,text=True)
new=(ROOT/'dm/host/hle_fs.c').read_text()
def migration(s): return s[s.index('static int kh2_save_migrate_on'):s.index('static Result mount_ex')]
assert migration(old)==migration(new)
summary['unchanged_migration']=True
for path in ['dm/host/tests/t_fs.c','dm/host/tests/t_fs_case.c','dm/host/tests/t_fs_commit_list.c','dm/host/tests/t_fs_save_adversarial.c','dm/games/settings.tsv']:
    assert subprocess.check_output(['git','show',summary['base']+':'+path],cwd=ROOT)==(ROOT/path).read_bytes(),path
summary['prior_assertion_sources_and_settings_unchanged']=True
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
dest=ROOT/'docs/agents/kh2-save-r1-summary.json'
dest.write_text(json.dumps(summary,indent=2)+'\n')
archive=ROOT/'docs/agents/kh2-save-r1-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for p in sorted(OUT.rglob('*')):
        rel=p.relative_to(OUT)
        if p.is_file() and p.suffix in ['.log','.json','.c','.py'] and not any(x in rel.parts for x in ['fixtures','__pycache__']) and not any(x.endswith('.dSYM') for x in rel.parts):
            tf.add(p,arcname=str(Path('kh2-save-r1-evidence')/rel))
with tarfile.open(archive) as tf: members=tf.getnames()
assert all(not x.startswith('/') and '..' not in Path(x).parts for x in members)
print(json.dumps({k:dict(v,failed_commands=len(v['failed_commands'])) for k,v in summary['runs'].items()},indent=2))
print('archive',len(members),'files',archive.stat().st_size,'bytes',hashlib.sha256(archive.read_bytes()).hexdigest())
print('production',summary['hashes']['dm/host/hle_fs.c'])
