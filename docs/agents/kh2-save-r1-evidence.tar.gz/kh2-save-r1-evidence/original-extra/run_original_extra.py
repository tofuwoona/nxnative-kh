#!/usr/bin/env python3
from pathlib import Path
import subprocess, os, re, json, hashlib, sys, struct
ROOT=Path('/Users/tofu/.hermes/cache/scratch/kh-save-r1')
OUT=Path('/Users/tofu/.hermes/cache/scratch/kh-save-r1-evidence/original-extra')
TESTS=ROOT/'dm/host/tests'
ENV=dict(os.environ,TMPDIR='/Users/tofu/.hermes/cache/scratch/kh-save-r1-evidence/original-extra/fixtures',ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1')
for k in ['DM_KH2_SAVE_FIX_MIGRATE','DM_TEST_FS_FAIL','DM_TEST_KILL_AT','DM_TEST_FS_FAILAT']: ENV.pop(k,None)
rows=[]
def run(label,cmd,cwd=TESTS):
 p=subprocess.run(cmd,cwd=cwd,env=ENV,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 log=OUT/(label+'.log'); log.write_text(p.stdout)
 rows.append(dict(label=label,command=cmd,cwd=str(cwd),exit_code=p.returncode,log=str(log)))
 print(label,p.returncode,p.stdout[-240:],flush=True)
 return p.returncode
# Original independent assertions, not implementer's expanded retry/cold expectations.
orig=Path('/Users/tofu/Documents/Workspace/kh2-save-review-108/dm/host/tests/t_fs_save_adversarial.c').read_text()
expanded=(TESTS/'t_fs_save_adversarial.c').read_text()
orig=orig.replace('#include "../../ios/Sources/log_rotation.h"','#include "'+str(ROOT/'dm/ios/Sources/log_rotation.h')+'"').replace('#include "../hle_fs.c"','#include "'+str(ROOT/'dm/host/hle_fs.c')+'"').replace('atomic_load(&g_save_poison)','atomic_load(&g_save_poison[0])')
# Necessary schedule fix: original main-thread Commit blocked releasing writer.
start=orig.index('static Result writer_result;'); end=orig.index('static void short_io(void)',start)
new=expanded[expanded.index('static Result writer_result;'):expanded.index('static void short_io(void)')].replace('REVIEW_POISON','atomic_load(&g_save_poison[0])')
orig=orig[:start]+new+orig[end:]
original_path=OUT/'t_original_repros.c'; original_path.write_text(orig)
for tag,game in [('kh2','010090C022978003'),('kh1','010090C022978001')]:
 flags=['clang','-O1','-g','-Wno-unused-function','-I..','-I../gen/'+game]
 exe=OUT/('t_original_'+tag)
 if not run('original-build-'+tag,flags+['-o',str(exe),str(original_path),'t_fs_stub.c','../hle_bigstack.c']):
  for case in ['create-failure','readonly-path','held-handle','clone-failure','swap-failure','concurrent-commit','recursive-failure']:
   run('original-'+tag+'-'+case,[str(exe),case])
exe=OUT/'t_sanitized_kh2'
flags=['clang','-O1','-g','-Wno-unused-function','-I..','-I../gen/010090C022978003','-fsanitize=address,undefined','-fno-omit-frame-pointer']
if not run('sanitized-build',flags+['-o',str(exe),'t_fs_save_adversarial.c','t_save_adversarial_stub.c','../hle_bigstack.c']):
 data=json.loads((Path('/Users/tofu/.hermes/cache/scratch/kh-save-r1-evidence/prior-green/test-results.json')).read_text())
 for r in data:
  if r['label'].startswith('kh2-adversarial-'): run('sanitized-'+r['command'][-1],[str(exe),r['command'][-1]])
(OUT/'extra-test-results.json').write_text(json.dumps(rows,indent=2))
# Exact bytes / git lineage; no original saves accessed.
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'base':'70eca8a8c1dfefe972ae91a5851fbe5aaa6a3205','common_dir':subprocess.check_output(['git','rev-parse','--git-common-dir'],cwd=ROOT,text=True).strip(),'files':{}}
for f in ['dm/host/hle_fs.c','dm/games/settings.tsv','dm/host/gen/010090C022978003/game_profile.h','dm/host/gen/010090C022978001/game_profile.h']:
 meta['files'][f]=hashlib.sha256((ROOT/f).read_bytes()).hexdigest()
(OUT/'source-provenance.json').write_text(json.dumps(meta,indent=2))
print('EXTRA FAILURES',[r['label'] for r in rows if r['exit_code']])
